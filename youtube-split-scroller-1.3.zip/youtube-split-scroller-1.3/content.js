const SELECTORS = {
    root: 'ytd-watch-flexy',
    primary: '#primary',
    secondary: '#secondary',
    topbar: '#masthead-container, #masthead',
};

const DEBOUNCE_MS = 150;

function debounce(fn, delay) {
    let timer = null;

    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

function computeTopHeight() {
    const topbar = document.querySelector(SELECTORS.topbar);
    return topbar ? topbar.offsetHeight : 56;
}

function applySplitScroll() {
    const root = document.querySelector(SELECTORS.root);
    const primary = document.querySelector(SELECTORS.primary);
    const secondary = document.querySelector(SELECTORS.secondary);

    if (!root || !primary || !secondary) {
        return false;
    }

    const topHeight = computeTopHeight();
    const heightValue = `calc(100vh - ${topHeight}px)`;

    document.documentElement.dataset.splitScroll = 'enabled';
    document.body.dataset.splitScroll = 'enabled';
    document.documentElement.style.setProperty('--ytsplit-top', `${topHeight}px`);
    document.documentElement.style.setProperty('--ytsplit-height', heightValue);

    return true;
}

function observeYouTube() {
    const observer = new MutationObserver(() => applySplitScroll());

    observer.observe(document.documentElement, { childList: true, subtree: true });
    applySplitScroll();

    return observer;
}

function onNavigation() {
    applySplitScroll();
}

observeYouTube();
window.addEventListener('resize', debounce(applySplitScroll, DEBOUNCE_MS));
document.addEventListener('yt-navigate-finish', debounce(onNavigation, DEBOUNCE_MS));
document.addEventListener('yt-page-data-updated', debounce(onNavigation, DEBOUNCE_MS));
