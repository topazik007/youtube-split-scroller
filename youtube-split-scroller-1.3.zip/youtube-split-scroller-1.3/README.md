# youtube-split-scroller
Allows you to scroll through a list of recommended videos on the right, independent of the main content.

A Chrome browser extension that separates the scroll of the main content
(player + comments) and the recommended videos sidebar on YouTube.

Installation
------------

1. Download the repository:
[![Download](https://img.shields.io/badge/Download-ZIP-brightgreen)](https://github.com/topazik007/youtube-split-scroller/archive/refs/tags/1.0.zip)
   
2. Open Chrome and go to chrome://extensions/
3. Enable Developer mode (toggle in the top right corner)
4. Click Load unpacked and select the extension folder
5. Done — open any YouTube video and try it out

Compatibility
-------------

Works on YouTube watch pages (youtube.com/watch).
Tested in Google Chrome and any Chromium-based browser
(Edge, Brave, Opera, Arc, etc.).

License
-------

MIT — feel free to use, modify, and share.
